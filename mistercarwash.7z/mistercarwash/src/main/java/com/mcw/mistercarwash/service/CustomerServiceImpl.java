package com.mcw.mistercarwash.service;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.mcw.mistercarwash.model.Customer;
import com.mcw.mistercarwash.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements ICustomerService,UserDetailsService {
	
	@Autowired
	private CustomerRepository repo;
	
	@Autowired
	private BCryptPasswordEncoder pwdEncoder;

	@Override
	public Integer saveCustomer(Customer customer) {
		customer.setPassword(pwdEncoder.encode(customer.getPassword()));
		return repo.save(customer).getId();
	}

	@Override
	public Optional<Customer> findByUsername(String username) {
		return repo.findByUsername(username);
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<Customer> opt = findByUsername(username);
		if(!opt.isPresent())
				throw new UsernameNotFoundException("User Not Exists");
		
		Customer cust = opt.get();
		return new User(username, cust.getPassword(), new ArrayList<>());
	}
}
