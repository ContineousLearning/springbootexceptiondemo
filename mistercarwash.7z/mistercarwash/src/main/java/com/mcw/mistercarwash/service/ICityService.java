package com.mcw.mistercarwash.service;

import java.util.List;

import com.mcw.mistercarwash.model.City;

public interface ICityService {
	Integer saveCity(City c);
	List<City> getAllCities();
	City getCityByID(Integer id);
}
