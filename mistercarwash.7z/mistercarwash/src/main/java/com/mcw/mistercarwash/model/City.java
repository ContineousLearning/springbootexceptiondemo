package com.mcw.mistercarwash.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;



@Entity
@Table(name="citytab")
public class City {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID")
	private Integer id;
	
	@NotNull(message = "City cannot be null")
	@NotBlank(message = "City cannot be blank")
	@Size(min = 2, message = "City name should have atleast 2 characters")
	@Column(name="Name")
	private String name;
	
	@NotNull
	@Size(min = 3,max = 3, message = "Country should be 3 character code")
	@Column(name="CountryCode")
	private String countryCode;
	
	@NotNull
	@Size(min = 2, message = "District name should have atleast 2 characters")
	@Column(name="District")
	private String district;
	
	@Column(name="Population")
	private String population;
	
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getPopulation() {
		return population;
	}
	public void setPopulation(String population) {
		this.population = population;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}
	
	
}
