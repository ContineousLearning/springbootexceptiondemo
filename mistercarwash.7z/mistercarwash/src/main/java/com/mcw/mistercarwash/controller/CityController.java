package com.mcw.mistercarwash.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mcw.mistercarwash.model.City;
import com.mcw.mistercarwash.service.ICityService;

@RestController
public class CityController {
	
	@Autowired
	private ICityService service;
	
	Logger logger = LoggerFactory.getLogger(CityController.class);
	
	@PostMapping("/city")
	public ResponseEntity<String> saveCity(@Valid @RequestBody City city){
		Integer id = service.saveCity(city);
		return new ResponseEntity<String>("City save with id: "+id,HttpStatus.CREATED);
	}
	
	@GetMapping("/cities")
	public ResponseEntity<List<City>> getAllCities(){ 
		List<City> list = service.getAllCities();
		return new ResponseEntity<List<City>>(list,HttpStatus.OK);
	}
	
	@GetMapping("/city/{id}")
	public ResponseEntity<City> getAllCities(@PathVariable (value = "id") Integer id){ 
		City city = service.getCityByID(id);
		return new ResponseEntity<City>(city,HttpStatus.OK);
	}

}
