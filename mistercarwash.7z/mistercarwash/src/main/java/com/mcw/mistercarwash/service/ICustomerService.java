package com.mcw.mistercarwash.service;

import java.util.Optional;

import com.mcw.mistercarwash.model.Customer;

public interface ICustomerService {
	
	Integer saveCustomer(Customer customer);
	Optional<Customer> findByUsername(String username);

}
