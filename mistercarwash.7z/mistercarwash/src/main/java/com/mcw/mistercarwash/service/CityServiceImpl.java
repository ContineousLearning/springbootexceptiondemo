package com.mcw.mistercarwash.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mcw.mistercarwash.exception.ResourceNotFoundException;
import com.mcw.mistercarwash.model.City;
import com.mcw.mistercarwash.repository.CityRepository;

@Service
public class CityServiceImpl implements ICityService {
	
	@Autowired
	private CityRepository repo;
	
	@Override
	public Integer saveCity(City c) {
		c = repo.save(c);
		return c.getId();
	}

	@Override
	public List<City> getAllCities() {
		List<City> list = repo.findAll();
		return list;
	}

	@Override
	public City getCityByID(Integer id) {
		return this.repo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("City not found with id :"+id));

	}

}
