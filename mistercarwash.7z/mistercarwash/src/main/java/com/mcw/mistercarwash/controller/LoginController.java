package com.mcw.mistercarwash.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mcw.mistercarwash.model.Customer;
import com.mcw.mistercarwash.model.UserRequest;
import com.mcw.mistercarwash.model.UserResponse;
import com.mcw.mistercarwash.service.ICustomerService;
import com.mcw.mistercarwash.util.JwtUtil;


@RestController
@RequestMapping("/customer")
public class LoginController {
	
	Logger logger = LoggerFactory.getLogger(LoginController.class);
	
	@Autowired
	JwtUtil util;
	
	@Autowired
	private ICustomerService service;
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@GetMapping("/welcome")
	public ResponseEntity<String> getMessage() {
		logger.warn("This is warn message");
		logger.error("This is error message");
		logger.info("This is info message");
		return new ResponseEntity<>("WELCOME MISTER CAR WASH",HttpStatus.OK);
	}
	
	@GetMapping("/getById")
	public ResponseEntity<String> getById(@RequestParam String name) {		
		return new ResponseEntity<>("WELCOME:" +name,HttpStatus.OK);
	}
	
	@PostMapping("/login")
	public ResponseEntity<UserResponse> loginCustomer(@RequestBody UserRequest request){
		
		authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(
				request.getUsername(), request.getPassword()));
		String token = util.generateToken(request.getUsername());
		return ResponseEntity.ok(new UserResponse(token,"Success"));
		
	}
	
	@PostMapping("/save")
	public ResponseEntity<String> saveCustomer(@RequestBody Customer customer){
		Integer id = service.saveCustomer(customer);
		return ResponseEntity.ok("Customer saved id: "+id);
		
	}
	
}
