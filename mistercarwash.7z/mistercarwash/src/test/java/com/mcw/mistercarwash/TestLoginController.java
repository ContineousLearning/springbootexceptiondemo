package com.mcw.mistercarwash;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

@SpringBootTest(webEnvironment = WebEnvironment.MOCK)
@AutoConfigureMockMvc
public class TestLoginController {
	
	@Autowired
	private MockMvc mockMvc;
	
	@Test
	public void getCustomers() throws Exception{
		//create dummy request
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get("/getCustomers/all");
		//execute request and get result
		MvcResult result = mockMvc.perform(request).andReturn();
		//Read response
		MockHttpServletResponse response = result.getResponse();
		//Test using assert method
		assertEquals(HttpStatus.OK.value(),response.getStatus());
		assertEquals(MediaType.APPLICATION_JSON_VALUE,response.getContentType());
	}
}
